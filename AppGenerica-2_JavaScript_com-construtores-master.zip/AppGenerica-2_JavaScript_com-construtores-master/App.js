class App {
	
	constructor() {
		this.coleção = new Coleção();
	}
	
}

