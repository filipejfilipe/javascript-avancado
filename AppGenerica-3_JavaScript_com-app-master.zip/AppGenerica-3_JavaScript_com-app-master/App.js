class App {
	
	constructor() {
		this.coleção = new Coleção();
		this.collection = new Collection();
	}
	
}

