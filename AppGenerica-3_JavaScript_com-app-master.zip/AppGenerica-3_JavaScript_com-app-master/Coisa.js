function Coisa(nome, valor) {

	this.nome = nome;
	this.valor = valor;

}
