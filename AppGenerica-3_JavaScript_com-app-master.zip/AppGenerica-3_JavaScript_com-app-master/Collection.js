class Collection {
	
	constructor() {
		this.thing0 = new Thing("zyx", 321);
		this.thing1= new Thing("wuv", 654);
	}
	
}