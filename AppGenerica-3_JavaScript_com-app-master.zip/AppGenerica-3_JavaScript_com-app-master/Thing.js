function Thing(name, value) {

	this.name= name;
	this.value = value;

}
