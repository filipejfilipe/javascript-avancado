function Cliente(rua, número, cidade, códigoPostalPrincipal, códigoPostalsecundário, nome, email, telemóvel) {

	this.rua = rua;
	this.número = número;
	this.cidade = cidade;
	this.códigoPostalPrincipal = códigoPostalPrincipal;
	this.códigoPostalsecundário = códigoPostalsecundário;
	this.nome = nome;
	this.email = email;
	this.telemóvel = telemóvel;

}
