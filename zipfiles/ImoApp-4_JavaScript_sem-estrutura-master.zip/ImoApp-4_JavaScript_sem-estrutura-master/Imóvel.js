function Imóvel(rua, número, cidade, códigoPostalPrincipal, códigoPostalsecundário, valor) {

	this.rua = rua;
	this.número = número;
	this.cidade = cidade;
	this.códigoPostalPrincipal = códigoPostalPrincipal;
	this.códigoPostalsecundário = códigoPostalsecundário;
	this.valor = valor;

}
