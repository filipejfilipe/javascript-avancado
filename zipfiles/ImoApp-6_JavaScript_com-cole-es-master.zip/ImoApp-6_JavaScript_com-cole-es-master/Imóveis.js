class Imóveis {

	constructor() {
		this.coleção = new Array();
		this.coleção[0] = new Imóvel("Rua do Olival", 40, "Lisboa", 1200, 739, 75000);
		this.coleção[1] = new Imóvel("Travessa da Azeitona", 75, "Lisboa", 1300, 350, 175000);
	}

}
