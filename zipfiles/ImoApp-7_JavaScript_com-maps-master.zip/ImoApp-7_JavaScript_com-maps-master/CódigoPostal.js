function CódigoPostal(principal, secundário) {

	this.principal = principal;
	this.secundário = secundário;

}