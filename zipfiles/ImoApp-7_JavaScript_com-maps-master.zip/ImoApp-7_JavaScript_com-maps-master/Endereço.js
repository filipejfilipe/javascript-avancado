class Endereço {

	constructor(rua, número, cidade, códigoPostal) {
		this.rua = rua;
		this.número = número;
		this.cidade = cidade;
		this.códigoPostal = códigoPostal;
	}

}