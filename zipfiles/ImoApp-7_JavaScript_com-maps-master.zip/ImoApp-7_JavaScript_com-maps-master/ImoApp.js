class ImoApp {

	constructor() {
		this.clientes = new Clientes();
		this.imóveis = new Imóveis();
	}

}

