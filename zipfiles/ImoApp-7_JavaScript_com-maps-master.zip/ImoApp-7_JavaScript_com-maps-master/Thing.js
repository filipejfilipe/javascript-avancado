class Thing {

	nome = "thing";

	constructor(nome) {
		this.nome = nome;
	}

}