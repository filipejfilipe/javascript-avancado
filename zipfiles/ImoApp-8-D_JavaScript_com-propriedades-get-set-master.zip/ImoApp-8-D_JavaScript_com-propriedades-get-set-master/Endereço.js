class Endereço {

	constructor(rua, número, cidade, freguesia) {
		this.rua = rua;
		this.número = número;
		this.cidade = cidade;
		this.freguesia = freguesia;
	}

}