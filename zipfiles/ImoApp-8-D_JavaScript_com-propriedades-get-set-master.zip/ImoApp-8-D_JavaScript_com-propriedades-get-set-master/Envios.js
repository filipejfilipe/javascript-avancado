var Comunicação = {};

Comunicação.validarEmail = function(email) { // verificação simplificado se trata-se de um email
	// todo
	return email; // ou não
};

Comunicação.validarTelefone = function(telefone) { // verificação simplificado se trata-se de um telefone
	// todo
	return telefone; // ou não
};
