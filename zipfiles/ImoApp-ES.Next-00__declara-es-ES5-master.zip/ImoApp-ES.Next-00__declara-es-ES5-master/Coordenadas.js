
function Coordenadas(x, y) {

	this.x = x;
	this.y = y;

}

Coordenadas.prototype.toString = function () {
	return "Coordenadas (" + this.x + ", " + this.y + ")";
};



