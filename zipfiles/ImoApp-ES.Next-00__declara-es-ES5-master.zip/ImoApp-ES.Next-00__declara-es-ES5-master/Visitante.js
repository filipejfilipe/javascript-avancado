function Visitante() {

	this.imoGUI = new ImoGUI(new ImoApp().simular());

}