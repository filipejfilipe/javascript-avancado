class Visitante {

	constructor() {
		this.imoGUI = new ImoGUI(new ImoApp().simular());
	}

}