
export default  class Endereço {

	constructor(rua, número, códigoPostal, país) {
		this.rua = rua;
		this.número = número;
		this.códigoPostal = códigoPostal;
		this.país = país;
	}

};